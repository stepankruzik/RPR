﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hra2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Player hrac = new Player("Bojovník");
            string hracInfo = "Hráč vytvořen:\n" + hrac.ToString();

            hrac.levelUp(120);
            hracInfo += $"\n\nPo přidání 120 XP:\n{hrac.ToString()}";

            hrac.changePosition(5, 10);
            hracInfo += $"\n\nNová pozice hráče: X = {hrac.positionX}, Y = {hrac.positionY}";

            NPC npc = new NPC("Obchodník");
            string npcInfo = "NPC vytvořeno:\n" + npc.ToString();

            npc.changePosition(7, 3);
            npcInfo += $"\n\nNová pozice NPC: X = {npc.positionX}, Y = {npc.positionY} (nemělo by se změnit)";

            MessageBox.Show(hracInfo, "Hráč Info");
            MessageBox.Show(npcInfo, "NPC Info");
        }
    }
}
