﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hra2
{
    public class GameCharacter
    {
        public string name { get; set; }
        public int positionX { get; private set; }
        public int positionY { get; private set; }
        public int level { get; protected set; }

        public GameCharacter(string name)
        {
            this.name = name;
            this.positionX = 0;
            this.positionY = 0;
            this.level = 1;
        }

        public void changePosition(int x, int y)
        {
            positionX = x;
            positionY = y;
        }

        public override string ToString()
        {
            return $"Jméno: {name}\nLevel: {level}\nPozice: ({positionX}, {positionY})";
        }
    }
}
