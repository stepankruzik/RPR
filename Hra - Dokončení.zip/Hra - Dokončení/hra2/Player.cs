﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hra2
{
        /*
        public string name { get; set; }
        public int positionX { get; private set; }
        public int positionY { get; private set; }
        public int level { get; protected set; }

        public Player(string name)
        {
            this.name = name;
            this.positionX = 0;
            this.positionY = 0;
            this.level = 1;
        }

        public void changePosition(int x, int y)
        {
            positionX = x;
            positionY = y;
        }

        public override string ToString()
        {
            return $"Jméno: {name}\nLevel: {level}\nPozice: ({positionX}, {positionY})";
        }
    }
        */

    public class Player : GameCharacter
    {
        public string role { get; private set; }
        public int faceExpression { get; private set; }
        public int hair { get; private set; }
        public int hairColor { get; private set; }
        public int xp { get; private set; }

        private static readonly string[] roles = { "Kouzelník", "Berserker", "Inženýr", "Cizák" };
        private static readonly Random rand = new Random();

        public Player(string name) : base(name)
        {
            role = roles[rand.Next(roles.Length)];
            faceExpression = 0;
            hair = 0;
            hairColor = 0;
            xp = 0;
        }

        public void levelUp(int gainedXP)
        {
            xp += gainedXP;
            if (xp >= 100)
            {
                level++;
                xp -= 100;
            }
        }

        public override string ToString()
        {
            return $"Jméno: {name}\nLevel: {level}\nXP: {xp}\nSpecializace: {role}\nPozice: ({positionX}, {positionY})";
        }


    }

    /*
    public class NPC : Player
    {
        public NPC(string name) : base(name) { }

        public new void changePosition(int x, int y)
        {
            NPC se nemůže pohybovat, proto pozice zůstává stejná
        }

        public override string ToString()
        {
            return $"Jméno: {name}\nLevel: {level}\nPozice: ({positionX}, {positionY})";
        }
    }
    */
}
