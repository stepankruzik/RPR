﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace hra2
{
    internal class NPC : GameCharacter
    {
        public NPC(string name) : base(name) { }

        public new void changePosition(int x, int y)
        {
            
        }

        public override string ToString()
        {
            return $"Jméno: {name}\nLevel: {level}\nPozice: ({positionX}, {positionY})";
        }
    }
}